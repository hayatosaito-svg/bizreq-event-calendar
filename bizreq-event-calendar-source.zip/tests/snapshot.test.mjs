import test from 'node:test';
import assert from 'node:assert/strict';
import {createSnapshot, readSnapshot, snapshotIsFresh, SNAPSHOT_TTL_MS} from '../src/snapshot.mjs';

const now = Date.parse('2026-10-30T07:00:00Z');
const event = {id:'event',title:'公開イベント',stopped:false,cutoff:now+3600000};
const feed = {events:[event],sources:[],warnings:[],checkedAt:new Date(now).toISOString()};
const snapshot = {...feed,validUntil:new Date(now+SNAPSHOT_TTL_MS).toISOString()};

test('a fresh snapshot retains stop flags and removes elapsed events', () => {
  const data = readSnapshot({...snapshot, events:[event,{...event,id:'stopped',stopped:true},{...event,id:'expired',cutoff:now}]},now);
  assert.deepEqual(data.events.map(e=>[e.id,e.stopped]),[['event',false],['stopped',true]]);
});
test('an expired, missing, future-dated or overlong snapshot is unavailable', () => {
  assert.equal(snapshotIsFresh(snapshot,now+SNAPSHOT_TTL_MS),false);
  for (const patch of [
    {checkedAt:null},{validUntil:null},{error:'unavailable'},
    {checkedAt:new Date(now+120000).toISOString()},
    {validUntil:new Date(now+SNAPSHOT_TTL_MS+1).toISOString()},
    {events:[{...event,stopped:undefined}]}
  ]) assert.throws(()=>readSnapshot({...snapshot,...patch},now));
});
test('failed upstreams publish a closed state without the previous events', async () => {
  const data=await createSnapshot(async()=>{throw new Error('STOP_STATE_UNAVAILABLE');},now);
  assert.deepEqual(data.events,[]);
  assert.equal(snapshotIsFresh(data,now),false);
  assert.ok(data.error);
});
test('successful generation sets a bounded lifetime from the source check', async () => {
  const data=await createSnapshot(async()=>feed,now);
  assert.equal(Date.parse(data.validUntil)-Date.parse(data.checkedAt),SNAPSHOT_TTL_MS);
  assert.equal(readSnapshot(data,now+1).events.length,1);
});
