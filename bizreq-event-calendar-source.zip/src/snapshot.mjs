export const SNAPSHOT_TTL_MS = 10 * 60 * 1000;

// Pages serves a static snapshot. Never keep accepting applications indefinitely
// if the scheduled job, its upstream stop API, or the deployment stops working.
export function snapshotIsFresh(data, now = Date.now()) {
  const checkedAt = Date.parse(data?.checkedAt || '');
  const validUntil = Date.parse(data?.validUntil || '');
  return !data?.error && Number.isFinite(checkedAt) && Number.isFinite(validUntil)
    && checkedAt <= now + 60000 && validUntil > now
    && validUntil <= checkedAt + SNAPSHOT_TTL_MS;
}

export function readSnapshot(data, now = Date.now()) {
  if (!snapshotIsFresh(data, now) || !Array.isArray(data.events)
    || !Array.isArray(data.sources) || !Array.isArray(data.warnings)) {
    throw new Error('CALENDAR_SNAPSHOT_UNAVAILABLE');
  }
  if (!data.events.every(e => e && typeof e.id === 'string'
    && typeof e.title === 'string' && typeof e.stopped === 'boolean'
    && Number.isFinite(e.cutoff))) throw new Error('INVALID_CALENDAR_SNAPSHOT');
  return {...data, events: data.events.filter(e => e.cutoff > now)};
}

export async function createSnapshot(loader, now = Date.now()) {
  try {
    const feed = await loader();
    const checkedAt = Date.parse(feed.checkedAt);
    const data = {...feed, validUntil: new Date(checkedAt + SNAPSHOT_TTL_MS).toISOString()};
    return readSnapshot(data, now);
  } catch {
    return {
      error: '最新の受付状況を確認できません。更新が復旧するまで申込案内を停止しています。',
      events: [], sources: [], warnings: [],
      checkedAt: new Date(now).toISOString(), validUntil: new Date(now).toISOString()
    };
  }
}
