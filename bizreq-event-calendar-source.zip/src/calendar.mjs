// Read only published, sanitized feeds. Private source sheets are not exposed.
const SOURCE_NAMES={glow_agents:'Glowperson 就活支援',givez:'Givez',evoke:'EVOKE',shared:'共有シート',attackon:'AttackOn'};
export const SOURCES=[['glow','Glowperson','https://bizreq.co.jp/wp-json/bizreq/v1/glow-events'],['direct','直案件','https://bizreq.co.jp/wp-json/bizreq/v1/direct-cases'],['partner','提携案件','https://bizreq.co.jp/wp-json/bizreq/v1/partner-cases']];
const STOPS='https://student.bizreq.co.jp/api/checker/stops';
const key=s=>String(s||'').normalize('NFKC').replace(/\s+/g,'').trim();
const jst=ts=>new Date(ts+32400000).toISOString();
export function cutoffOf(row){const candidates=[row['開始日時'],row['申込締切日時'],row['申込締切']];for(const m of String(row['案件概要']||'').matchAll(/【申込締切】\s*([^\n]+)/g))candidates.push(m[1]);return Math.min(...candidates.map(v=>{if(!v)return NaN;const s=String(v).trim();if(/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d\d:\d\d)$/.test(s))return Date.parse(s);const m=s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:\s+(\d\d?):(\d\d))?/);return m?Date.UTC(+m[1],+m[2]-1,+m[3],m[4]?+m[4]-9:15,+(m[5]||0)):NaN;}).filter(Number.isFinite));}
export function stopped(row,stops){const start=Date.parse(row['開始日時']),stamp=jst(start),date=stamp.slice(0,10),time=stamp.slice(11,16),ref=JSON.stringify([row['企業ID']||'',date,time]);return stops.some(s=>(s.sourceRefs||[]).includes(ref)||(!s.date||s.date===date)&&[s.name,...(s.names||[])].some(n=>key(n)===key(row['案件名'])));}
function areaOf(r){if(r['開催形式']==='online')return 'オンライン';const text=String(r['開催場所']||'')+' '+String(r['案件名']||'')+' '+String(r['案件概要']||'');for(const a of ['東京','大阪','名古屋','福岡','仙台','札幌','神戸','京都','広島','横浜','静岡'])if(text.includes(a))return a;return '会場は詳細へ';}
export function mergeFeeds(results,stopData,now=Date.now()){
 if(!stopData||!Array.isArray(stopData.stopped)||!stopData.stopped.every(s=>s&&typeof s.name==='string'&&Array.isArray(s.sourceRefs)&&Array.isArray(s.names)))throw new Error('STOP_STATE_UNAVAILABLE');
 const sources=[],warnings=[],candidates=[];
 for(const [index,[id,name]] of SOURCES.entries()){
  const result=results[index],data=result?.status==='fulfilled'?result.value:null;
  if(!data||!Array.isArray(data.items)){sources.push({name,updatedAt:null,count:0,stale:true});warnings.push(name);continue;}
  const entries=id==='partner'?Object.entries(data.sources||{}):[[id,data]];
  if(!entries.length){sources.push({name,updatedAt:null,count:0,stale:true});warnings.push(name);}
  for(const [sourceId,state] of entries){
   const label=id==='partner'?(SOURCE_NAMES[sourceId]||'追加の連携元'):name;
   const time=Date.parse(state.updated_at||'');
   const stale=Boolean(state.stale)||!Number.isFinite(time)||now-time>900000;
   const count=data.items.filter(r=>r['案件サービス']==='イベント'&&(id!=='partner'||r['連携元']===sourceId)&&cutoffOf(r)>now).length;
   sources.push({name:label,updatedAt:Number.isFinite(time)?state.updated_at:null,count,stale});if(stale)warnings.push(label);
  }
  for(const row of data.items){const state=id==='partner'?data.sources?.[row['連携元']]:data;const updated=Date.parse(state?.updated_at||'');if(!Number.isFinite(updated)||now-updated>172800000)continue;if(row['案件サービス']!=='イベント'||row['掲載ステータス']&&row['掲載ステータス']!=='掲載中'||!Number.isFinite(Date.parse(row['開始日時']))||cutoffOf(row)<=now)continue;candidates.push({row,source:id});}
 }
 const occurrence=r=>{const onecareer=String(r['公式詳細URL']||r['FV画像URL']||'').match(/(?:seminar\/|eye_catch_image\/)(\d+)/)?.[1];return onecareer?'onecareer:'+onecareer+':'+r['開始日時']:r['企業ID'];};
 // A direct contract replaces the duplicate provider occurrence, not other times.
 const own=new Set(candidates.filter(c=>c.source==='direct').map(c=>occurrence(c.row)));
 const selected=candidates.filter(c=>c.source==='direct'||!own.has(occurrence(c.row))),seen=new Set();
 const events=[];
 for(const {row:r,source} of selected){const id=String(r['企業ID']);if(!id||seen.has(id))continue;seen.add(id);const start=Date.parse(r['開始日時']),stamp=jst(start),desc=String(r['案件概要']||'');const endStamp=Date.parse(r['終了日時']||'');const end=Number.isFinite(endStamp)?jst(endStamp).slice(11,16):(desc.match(/【開催日時】[^\n]*[〜～~–-]\s*(\d{1,2}:\d{2})/)?.[1]||'');events.push({id,title:String(r['案件名']).replace(/｜\d{1,2}\/\d{1,2}\s+\d{1,2}:\d{2}[\s\S]*$/,'').replace(/\s+/g,' ').trim(),date:stamp.slice(0,10),time:stamp.slice(11,16),end,cutoff:cutoffOf(r),area:areaOf(r),years:String(r['対象卒年']||''),mode:r['開催形式']==='online'?'online':'offline',image:/^https:\/\//.test(r['FV画像URL']||'')?r['FV画像URL']:'',description:desc,appeal:String(r['訴求文']||''),stopped:stopped(r,stopData.stopped),source,sourceName:source==='partner'?(SOURCE_NAMES[r['連携元']]||'提携案件'):(source==='glow'?'Glowperson':'直案件')});}
 events.sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)||a.title.localeCompare(b.title,'ja'));
 const freshTimes=sources.filter(s=>!s.stale&&s.updatedAt).map(s=>s.updatedAt).sort();return {events,checkedAt:new Date(now).toISOString(),sourceUpdatedAt:freshTimes[0]||null,sources,warnings};
}
export async function loadCalendar(fetcher=fetch,now=Date.now()){
 const get=async url=>{const r=await fetcher(url,{cache:'no-store',headers:{Accept:'application/json'},signal:AbortSignal.timeout(16000)});if(!r.ok)throw new Error('UPSTREAM_UNAVAILABLE');const data=await r.json();if(!data||typeof data!=='object')throw new Error('INVALID_FEED');return data;};
 const all=await Promise.allSettled([...SOURCES.map(s=>get(s[2])),get(STOPS)]);
 if(all[3].status!=='fulfilled')throw new Error('STOP_STATE_UNAVAILABLE');
 if(all.slice(0,3).every(s=>s.status==='rejected'))throw new Error('FEEDS_UNAVAILABLE');
 return mergeFeeds(all.slice(0,3),all[3].value,now);
}
