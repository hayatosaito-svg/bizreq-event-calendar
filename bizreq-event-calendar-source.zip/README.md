# ビズリク 就活イベントカレンダー — GitHub Pages

既存の就活イベントカレンダーをGitHub Pagesで配信するための公開用ソースです。
月／一覧、検索、エリア・卒年・形式・提供元フィルタ、詳細、案内文コピー、スマートフォン表示、明暗切替を引き継いでいます。

## データ更新

- GitHub Actionsが公開済みのGlowperson・直案件・提携案件フィードと停止APIを読み、必要なイベント項目だけを静的JSONとして公開します。認証情報や非公開シートは使いません。
- 5分おきのスケジュールとmainへのpush、手動実行でビルド・配信します。AIは使いません。
- GitHubの混雑によりスケジュールは遅延・未実行になることがあります。公開リポジトリで60日間操作がない場合、GitHubが定期実行を停止することがあります。Actionsで状態を確認し、必要時は再有効化してください。
- 画面は1分ごと・タブ復帰時・手動更新時に配信済みJSONを再取得します。最新ボタンはGitHub Actionsを起動する操作ではありません。
- データの有効期限は停止状態の取得から10分です。期限切れ・取得失敗・停止APIの異常時は申込案内を出しません。開いた詳細も期限切れで閉じます。
- 停止変更の反映には次の取得・配信までの遅れがあります。即時反映を保証しません。原本のWordPress側の取込周期も別に存在します。

## 開発と公開

Node.js 22以上とpnpm 11.25.0で `pnpm install --frozen-lockfile --ignore-scripts --config.strict-dep-builds=false && pnpm test && pnpm run refresh && pnpm run build`。
プレビューは `pnpm run dev`。公開対象はdistだけです。

リポジトリのSettings → Pages → SourceをGitHub Actionsに設定し、mainにpushしてください。
新規リポジトリにはこのフォルダだけを登録し、元の業務ワークスペースや履歴は登録しません。
公開URLは実際のGitHub Pagesデプロイ完了画面から確認します。
