import {mkdir, writeFile} from 'node:fs/promises';
import {loadCalendar} from '../src/calendar.mjs';
import {createSnapshot} from '../src/snapshot.mjs';

const snapshot = await createSnapshot(() => loadCalendar());
await mkdir(new URL('../public/', import.meta.url), {recursive:true});
await writeFile(new URL('../public/events.json', import.meta.url), JSON.stringify(snapshot));
if (snapshot.error) {
  // Deploy the unavailable state too, so a failed upstream cannot leave old CTAs.
  console.warn('::warning::Calendar source unavailable; publishing a closed state.');
} else {
  console.log(JSON.stringify({events:snapshot.events.length,
    accepting:snapshot.events.filter(e=>!e.stopped).length,
    stopped:snapshot.events.filter(e=>e.stopped).length,
    checkedAt:snapshot.checkedAt, validUntil:snapshot.validUntil,
    warnings:snapshot.warnings}));
}
